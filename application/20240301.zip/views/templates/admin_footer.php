                    </div>
                </div>
            </div>
        </div>
        <a class="scroll-to-top rounded" href="#page-top" style="display: inline;">
            <i class="fas fa-angle-up"></i>
        </a>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
        <script src="<?= ASSETS_URL; ?>js/custom-scripts.js"></script>
        <script src="<?= ASSETS_URL; ?>js/controller.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('.toast').toast('show');
            });
        </script>
    </body>
</html>